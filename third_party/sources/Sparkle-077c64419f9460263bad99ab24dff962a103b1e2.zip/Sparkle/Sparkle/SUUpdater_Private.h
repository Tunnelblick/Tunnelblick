//
//  SUUpdater_Private.h
//  Sparkle
//
//  Created by Andy Matuschak on 5/9/11.
//  Copyright 2011 Andy Matuschak. All rights reserved.
//

#import "SUUpdater.h"

@interface SUUpdater (Private)

@property (readonly) BOOL mayUpdateAndRestart;

@end
